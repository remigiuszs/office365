Voraussetzungen:

SharePoint Plan 1
Modern Sites (Groups, Communication Site,...)

Best Practise:

Culture = ENGLISH
ansonsten wird "Spaces" als "Leerzeichen" übersetzt 